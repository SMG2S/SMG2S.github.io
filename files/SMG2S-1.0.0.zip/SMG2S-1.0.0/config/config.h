//#define __USE_COMPLEX__
#define __USE_DOUBLE__
//#define __USE_64BIT__
